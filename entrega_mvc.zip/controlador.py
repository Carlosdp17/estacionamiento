from tkinter import Tk
import vista


if __name__ == "__main__":
    root = Tk()
    vista.vista_principal(root)

    root.mainloop()
    